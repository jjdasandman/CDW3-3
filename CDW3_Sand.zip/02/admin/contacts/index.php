<?php
// Include any necessary files and functions
include '../../lib/ReadCSV.php';

// Retrieve data from your data source (e.g., CSV file)
$csvFilePath = '../../data/contacts.csv';
$contacts = ReadCSV($csvFilePath);

?>

<!DOCTYPE html>
<html>
<head>
    <title>Contact Request List</title>
</head>
<body>
    <h1>Contact Request List</h1>
    <table border="1">
        <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Subject</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($contacts as $contact) { ?>
                <tr>
                    <td><?= htmlspecialchars($contact[0]) ?></td>
                    <td><?= htmlspecialchars($contact[1]) ?></td>
                    <td><?= htmlspecialchars($contact[2]) ?></td>
                    <td><a href="detail.php?id=<?= urlencode($contact[0]) ?>">View Details</a></td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
	<p><a href="../dashboard.php">
	<button type="button" class="#">return to dashboard</button>
	</a></p>
</body>
</html>