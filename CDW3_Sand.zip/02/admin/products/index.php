<?php
// Include any necessary files and functions
include '../../lib/ReadCSV.php';

// Retrieve data from your data source (e.g., CSV file)
$csvFilePath = '../../data/products.csv';
$products = ReadCSV($csvFilePath);

?>

<!DOCTYPE html>
<html>
<head>
    <title>Product List</title>
</head>
<body>
    <h1>Product List</h1>
    <table border="1">
        <thead>
            <tr>
                <th>Product</th>
                <th>Description</th>
                <th>Applications</th>
                <th>Icon</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($products as $product) { ?>
                <tr>
                    <td><?= htmlspecialchars($product[0]) ?></td>
                    <td><?= htmlspecialchars($product[1]) ?></td>
                    <td><?= htmlspecialchars($product[2]) ?></td>
                    <td><?= htmlspecialchars($product[3]) ?></td>
                    <td><a href="detail.php?id=<?= urlencode($product[0]) ?>">View Details</a></td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
    <p><a href="create.php">Create New Product</a></p>
	<p><a href="../dashboard.php">
	<button type="button" class="#">return to dashboard</button>
	</a></p>
</body>
</html>