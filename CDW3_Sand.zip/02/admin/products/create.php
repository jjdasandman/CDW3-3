<?php
// Include any necessary files and functions
include '../../lib/ReadCSV.php';

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Process and validate the form data
    $name = $_POST['name'];
    $description = $_POST['description'];
    $application = $_POST['application'];
	$icon = $_POST['icon'];

    // Validate the form fields (you can add more validation as needed)
    if (empty($name) || empty($description) || empty($application) || empty($icon)) {
        echo 'All fields are required.';
        exit; // Terminate the script
    }

    // Add the new item to your data source (e.g., CSV file)
    // Specify the path to your CSV file
    $csvFilePath = '../../data/products.csv';

    // Prepare the data for the new item as an array
    $newItem = [$name, $description, $application, $icon];

    // Open the CSV file in append mode
    $csvFile = fopen($csvFilePath, 'a');

    // Lock the file for writing
    if (flock($csvFile, LOCK_EX)) {
        // Write the new item to the CSV file
        fputcsv($csvFile, $newItem);

        // Release the lock
        flock($csvFile, LOCK_UN);

        // Close the file
        fclose($csvFile);
    } else {
        // Handle the case where the file could not be locked (e.g., concurrent access)
        echo 'Unable to add the new item at this time. Please try again later.';
        exit; // Terminate the script
    }

    // Redirect the user to the edit page for the newly created item
    header('Location: edit.php?id=' . urlencode($newItem[0]));
    exit; // Terminate the script
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Create New Item</title>
</head>
<body>
     <h1>Create New Item</h1>
    <form method="POST" action="">
        <!-- Form fields for creating a new item -->
        <label for="name">Name:</label>
        <input type="text" name="name" id="name" required>

        <label for="description">Description:</label>
        <textarea name="description" id="description" required></textarea>

        <label for="application">Application:</label>
        <textarea name="application" id="application" required></textarea>
		
        <label for="icon">Icon:</label>
        <input type="text" name="icon" id="icon" required>

        <input type="submit" value="Create Item">
    </form>
    <p><a href="index.php">Back to Item List</a></p>
</body>
</html>