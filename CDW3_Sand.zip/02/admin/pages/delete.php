<?php
// Include any necessary files and functions
include '../../lib/CSVHelper.php';

// Specify the path to your CSV file
$csvFilePath = '../../data/navbar.csv';

// Check if a specific item is requested (e.g., based on query parameters)
if (isset($_GET['section'])) {
    $requestedSection = $_GET['section'];

    // Check if the user has confirmed the deletion
    if (isset($_POST['confirm']) && $_POST['confirm'] === 'yes') {
        // Use CSVHelper to delete the entry
        CSVHelper::deleteEntry($requestedSection);

        // Redirect the user to the index page
        header('Location: index.php');
        exit; // Terminate the script
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Delete Item</title>
</head>
<body>
    <h1>Delete Item</h1>

    <?php
    // Display a confirmation message and form for deletion
    if (isset($requestedSection)) {
        echo "Are you sure you want to delete the item with section: $requestedSection?";
    ?>
    <form method="post" action="">
        <label for="confirm">Confirm Deletion (type 'yes' to confirm):</label>
        <input type="text" name="confirm" id="confirm">
        <input type="submit" value="Delete">
    </form>
    <?php
    } else {
        echo 'Item not found.';
    }
    ?>

    <p><a href="index.php">Back to Item List</a></p>
</body>
</html>