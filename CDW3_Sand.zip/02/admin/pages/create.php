<?php
include '../../lib/CSVHelper.php'; // Include the CSVHelper class file

echo "you landed on the create page";

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Process and validate the form data
    $section = $_POST['section'];
    $link = $_POST['link'];

    // Validate the "link" input
    if (empty($link) || substr($link, 0, 1) !== '#') {
        // Handle the case where the "link" input is empty or doesn't start with a "#"
        echo 'The "link" field must not be empty and must start with "#".';
        exit; // Terminate the script
    }

    // Create a new entry using the CSVHelper
    CSVHelper::createEntry($section, $link);

    // Redirect to the index page
    header('Location: index.php');
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Create New Item</title>
</head>
<body>
    <h1>Create New Item</h1>
    <form method="POST" action="">
        <!-- Form fields for creating a new item -->
        <label for="section">Item Name:</label>
        <input type="text" name="section" id="section" required>

        <label for="link">Item Link:</label>
        <input type="text" name="link" id="link" required>

        <input type="submit" value="Create Item">
    </form>
    <p><a href="index.php">Back to Item List</a></p>
</body>
</html>