<?php
//TEAM delete
// Include any necessary files and functions
include '../../lib/ReadCSV.php';
// Retrieve data from your data source (e.g., CSV file)
$csvFilePath = '../../data/team.csv';
$data = ReadCSV($csvFilePath);
// Check if a specific item is requested (e.g., based on query parameters)
if (isset($_GET['section'])) {
    $requestedSection = $_GET['section'];

    // Check if the user has confirmed the deletion
    if (isset($_POST['confirm']) && $_POST['confirm'] === 'yes') {
        // Read the contents of the CSV file into an array
        $items = array_map('str_getcsv', file($csvFilePath));

        // Find and remove the item with the requested section
        $updatedItems = [];
        $deleted = false;
        foreach ($items as $item) {
            if ($item[0] === $requestedSection) {
                $deleted = true;
            } else {
                $updatedItems[] = $item;
            }
        }

        // If an item was deleted, write the updated array back to the CSV file
        if ($deleted) {
            $csvFile = fopen($csvFilePath, 'w');
            foreach ($updatedItems as $item) {
                fputcsv($csvFile, $item);
            }
            fclose($csvFile);
        }

        // Redirect the user to the index page
        header('Location: index.php');
        exit; // Terminate the script
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Delete Item</title>
</head>
<body>
    <h1>Delete Item</h1>

    <?php
    // Display a confirmation message and form for deletion
    if (isset($requestedSection)) {
        echo "Are you sure you want to delete this team member: $requestedSection?";
    ?>
    <form method="post" action="">
        <label for="confirm">Confirm Deletion (type 'yes' to confirm):</label>
        <input type="text" name="confirm" id="confirm">
        <input type="submit" value="Delete">
    </form>
    <?php
    } else {
        echo 'Item not found.';
    }
    ?>

    <p><a href="index.php">Back to Item List</a></p>
</body>
</html>