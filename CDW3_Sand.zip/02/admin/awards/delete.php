<?php
/* AWARDS DELETE */

include '../../lib/JSONHelper.php';

// Set the JSON file path
JSONHelper::setJSONFilePath('../../data/awards.json');

// Check if the item should be deleted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm']) && $_POST['confirm'] === 'yes') {
    $year = $_GET['year'];
    $award_name = $_GET['award'];

    // Use the deleteEntry method to remove the item
    JSONHelper::deleteEntry($year, $award_name);

    // Redirect the user to the index page
    header('Location: index.php');
    exit;
}

// If the user hasn't confirmed the deletion, show the confirmation form
?>
<!DOCTYPE html>
<html>
<head>
    <title>Delete Award</title>
</head>
<body>
    <h1>Delete Award</h1>
    <p>Are you sure you want to delete this award?</p>
    <form method="post" action="">
        <input type="hidden" name="confirm" value="yes">
        <input type="submit" value="Yes, Delete">
    </form>
    <p><a href="index.php">Back to Awards List</a></p>
</body>
</html>