<?php
/* AWARDS CREATE */

include '../../lib/ReadJSON.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['year']) && isset($_POST['award']) && isset($_POST['source']) && isset($_POST['icon'])) {
        $newAward = [
            'year' => $_POST['year'],
            'award' => $_POST['award'],
            'source' => $_POST['source'],
            'icon' => $_POST['icon'],
        ];

        // Read the existing data from the JSON file
        $data = readJSON('../../data/awards.json');

        if (!is_array($data)) {
            $data = ['awards' => []];
        }

        // Append the new award to the data
        $data['awards'][] = $newAward;

        // Encode the data as JSON
        $jsonData = json_encode($data, JSON_PRETTY_PRINT);

        // Save the updated data to the JSON file
        file_put_contents('../../data/awards.json', $jsonData);

        // Redirect to the edit page for the newly created award
        //header("Location: edit.php?year=" . urlencode($newAward['year']));
		header("Location: index.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Create New Award</title>
</head>
<body>
    <h1>Create New Award</h1>
    <form method="POST" action="">
        <label for="year">Year:</label>
        <input type="text" name="year" id="year" required>

        <label for="award">Award:</label>
        <input type="text" name="award" id="award" required>

        <label for="source">Source:</label>
        <input type="text" name="source" id="source" required>

        <label for="icon">Icon:</label>
        <input type="text" name="icon" id="icon" required>
        
        <input type="submit" value="Create Award">
    </form>
    <p><a href="index.php">Back to Awards List</a></p>
</body>
</html>