<?php

class JSONHelper {
    private static $jsonFilePath;

    public static function setJSONFilePath($filePath) {
        self::$jsonFilePath = $filePath;
    }

    public static function readJSON() {
        // Check if the file path is set
        if (empty(self::$jsonFilePath)) {
            throw new Exception("JSON file path is not set.");
        }

        // Read JSON file and decode its content into an array
        $data = file_get_contents(self::$jsonFilePath);
        return json_decode($data, true);
    }

    public static function createEntry($year, $award, $source, $icon) {
        // Read existing data from JSON file
        $data = self::readJSON();

        // Add a new entry to the awards array
        $newEntry = [
            'year' => $year,
            'award' => $award,
            'source' => $source,
            'icon' => $icon
        ];

        $data['awards'][] = $newEntry;

        // Write the updated data back to the JSON file
        self::writeJSON($data);
    }

    public static function updateAward($oldYear, $newYear, $oldAward, $newAward, $source, $icon) {
        // Read existing data from JSON file
        $data = self::readJSON();

        // Find and update the entry with the specified old year and old award
        foreach ($data['awards'] as &$entry) {
            if ($entry['year'] === $oldYear && $entry['award'] === $oldAward) {
                // Update the entry with new values
                $entry['year'] = $newYear;
                $entry['award'] = $newAward;
                $entry['source'] = $source;
                $entry['icon'] = $icon;
                break;
            }
        }

        // Write the updated data back to the JSON file
        self::writeJSON($data);
    }

    public static function deleteEntry($year, $award) {
        // Read existing data from JSON file
        $data = self::readJSON();

        // Find and remove the entry with the specified year and award
        foreach ($data['awards'] as $key => $entry) {
            if ($entry['year'] === $year && $entry['award'] === $award) {
                unset($data['awards'][$key]);
                break;
            }
        }

        // Write the updated data back to the JSON file
        self::writeJSON($data);
    }

    private static function writeJSON($data) {
        // Encode the array as JSON and write it to the file
        file_put_contents(self::$jsonFilePath, json_encode($data, JSON_PRETTY_PRINT));
    }
}

?>