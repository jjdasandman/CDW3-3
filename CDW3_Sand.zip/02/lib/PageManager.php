<?php
include 'JSONHelper.php';

class PageManager {
    private $data; // Array to store pages data

    public function __construct() {
        // Load pages data from a JSON file
        $this->data = JSONHelper::readJSON('data/pages.json');
    }

    public function getPages() {
        return $this->data;
    }

    public function getPageById($id) {
        foreach ($this->data as $page) {
            if ($page['id'] == $id) {
                return $page;
            }
        }
        return null;
    }

    public function createPage($section, $link) {
    // Check if the form is submitted
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Process and validate the form data
        $section = $_POST['section'];
        $link = $_POST['link'];
        
        // Validate the "link" input
        if (empty($link) || substr($link, 0, 1) !== '#') {
            // Handle the case where the "link" input is empty or doesn't start with a "#"
            echo 'The "link" field must not be empty and must start with "#".';
            exit; // Terminate the script
        }
        
        // Add the new item to your data source (e.g., JSON or CSV file)
        
        // Specify the path to your JSON or CSV file
        $dataFilePath = 'path/to/your/data/file.json'; // Replace with the actual file path
        
        // Read the existing data from the JSON or CSV file
        $existingData = json_decode(file_get_contents($dataFilePath), true);
        
        // Add the new item to the data
        $newItem = ['section' => $section, 'link' => $link];
        $existingData[] = $newItem;
        
        // Write the updated data back to the JSON or CSV file
        file_put_contents($dataFilePath, json_encode($existingData, JSON_PRETTY_PRINT)); // Replace with the correct write method
        $exsistingLink = $link;
        // Redirect the user to the edit page for the newly created item
        header('Location: edit.php?section=' . urlencode($section). '&link=' . urlencode($exsistingLink));
        exit; // Terminate the script
    }
	}

    public function deletePage($id) {
        foreach ($this->data as $key => $page) {
            if ($page['id'] == $id) {
                unset($this->data[$key]);
                // Save the updated data to the JSON file
                JSONHelper::writeJSON('data/pages.json', $this->data);
                return true;
            }
        }
        return false;
    }
}
?>