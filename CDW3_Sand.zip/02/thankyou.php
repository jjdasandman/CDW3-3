<?php ?>
<!DOCTYPE html>
<html>
<head>
    <title>Thank You</title>
</head>
<body>
    <h1>Thank You for Your Submission</h1>
    <p>Your message has been successfully submitted.</p>
    <p><a href="index.php">Back to Homepage</a></p>
</body>
</html>
